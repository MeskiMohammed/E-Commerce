<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    
</head>
<body>
    <p class="text-red-600">hello laravel</p>
    <a href=<?php echo e(route('articles')); ?>><button class="m-2 p-2 rounded bg-cyan-700 hover:bg-cyan-600 transition-color duration-200 text-white">Articles</button></a>
</body>
</html><?php /**PATH C:\Users\PC\Desktop\laravel-app\resources\views/welcome.blade.php ENDPATH**/ ?>