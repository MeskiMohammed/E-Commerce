<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Article</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-slate-950 text-white flex flex-col items-center">
    <div class="text-cyan-600 text-center text-5xl font-bold my-2">Create a new Article</div>
    <br>
    <form action=<?php echo e(route('article.update',["article"=>$article->id])); ?> method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <table >
            <tr>
                <td>Designation :</td>
                <td><input value="<?php echo e($article->designation); ?>" class="bg-slate-950 outline outline-1" type="text" name="designation"></td>
            </tr>
            <tr>
                <td>Prix HT : </td>
                <td><input value="<?php echo e($article->prix_ht); ?>" class="bg-slate-950 outline outline-1" type="number" name="prix_ht"></td>
            </tr>
            <tr>
                <td>TVA : </td>
                <td><input value="<?php echo e($article->tva); ?>" class="bg-slate-950 outline outline-1" type="number" name="tva"></td>
            </tr>
            <tr>
                <td>Stock : </td>
                <td><input value="<?php echo e($article->stock); ?>" class="bg-slate-950 outline outline-1" type="number" name="stock"></td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="flex justify-center gap-2">
                        <button class="p-2 bg-cyan-600 hover:bg-cyan-500 rounded">Enregistrer</button>
                        <a href=<?php echo e(route('article.index')); ?>><button type="button" class="p-2 bg-cyan-600 hover:bg-cyan-500 rounded">Annuler</button></a>
                    </div>
                </td>
            </tr>
        </table>
    </form>
</body>

</html><?php /**PATH /home/user/laravel/resources/views/article/modify.blade.php ENDPATH**/ ?>