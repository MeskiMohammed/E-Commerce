<!DOCTYPE html>
<html lang="en">
<!-- head -->
<?php echo $__env->make('adminLayout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end head -->

<body>
    <!-- sidebar -->
    <?php echo $__env->make('adminLayout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end sidebar -->

    <main class="ease-soft-in-out xl:ml-62.5 relative h-screen rounded-xl transition-all duration-200">
        <!-- navbar -->
        <?php echo $__env->make('adminLayout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end navbar -->

        <div class="w-full px-6 py-6 mx-auto h-[calc(100%-calc(0.25rem*12))]">

            <div class="flex flex-wrap mt-6  h-[calc(100%-85px)] lg:h-[calc(100%-48px)]">
                <?php echo $__env->yieldContent('adminContent'); ?>
            </div>

            <!-- footer -->
            <?php echo $__env->make('adminLayout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end footer -->

        </div>
    </main>
</body>
<!-- scripts -->
<?php echo $__env->make('adminLayout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end scripts -->

</html><?php /**PATH /home/user/laravel/resources/views/adminLayout/app.blade.php ENDPATH**/ ?>