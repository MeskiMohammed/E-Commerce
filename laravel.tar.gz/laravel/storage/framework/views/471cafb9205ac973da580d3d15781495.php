<?php $__env->startSection('mini title','Ajouter un Famille'); ?>
<?php $__env->startSection('adminContent'); ?>
<form action="<?php echo e(route('familles.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="libelle">libelle :</label>
    <input type="text" name="libelle"><br>
    <label for="image">image :</label>
    <input type="file" name="image"><br>
    <button type="submit">Ajouter</button>
    <a href="<?php echo e(route('familles.index')); ?>"><button type="button">Annuler</button></a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/laravel/resources/views/familles/create.blade.php ENDPATH**/ ?>