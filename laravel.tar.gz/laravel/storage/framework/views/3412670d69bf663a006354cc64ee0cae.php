<!-- plugin for charts  -->
<script src="<?php echo e(asset('assets/js/plugins/chartjs.min.js')); ?>" async></script>
<!-- plugin for scrollbar  -->
<script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>" async></script>
<!-- github button -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- main script file  -->
<script src="<?php echo e(asset('assets/js/soft-ui-dashboard-tailwind.js?v=1.0.5')); ?>" async></script>
<!-- Perfect Scrollbar -->
<script src="<?php echo e(asset('assets/js/perfect-scrollbar.js')); ?>" async></script>

<?php /**PATH /home/user/laravel/resources/views/adminLayout/scripts.blade.php ENDPATH**/ ?>