<?php $__env->startSection('mini title','Ajoutet un Unite'); ?>
<?php $__env->startSection('adminContent'); ?>
<form action="<?php echo e(route('unites.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="unite">Unite :</label>
    <input type="text" name="unite"><br>
    <button type="submit">Ajouter</button>
    <a href="<?php echo e(route('unites.index')); ?>"><button type="button">Annuler</button></a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/laravel/resources/views/unites/create.blade.php ENDPATH**/ ?>