<?php $__env->startSection('mini title','Ajouter un Marque'); ?>
<?php $__env->startSection('adminContent'); ?>
<form action="<?php echo e(route('marques.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="marque">Marque :</label>
    <input type="text" name="marque"><br>
    <button type="submit">Ajouter</button>
    <a href="<?php echo e(route('marques.index')); ?>"><button type="button">Annuler</button></a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/laravel/resources/views/marques/create.blade.php ENDPATH**/ ?>