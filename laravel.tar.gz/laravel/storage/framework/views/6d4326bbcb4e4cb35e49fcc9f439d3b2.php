<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Stagiaire</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-slate-950 text-white flex flex-col items-center">
    <div class="text-cyan-600 text-center text-5xl font-bold my-2">Create a new Stagiaire</div>
    <br>
    <form action=<?php echo e(route('stagiaire.update',["stagiaire"=>$stagiaire->id])); ?> method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <table >
            <tr>
                <td>Filiere :</td>
                <td>
                    <select name="filiere_id" class="bg-slate-950 outline outline-1 focus:outline-white rounded">
                        <?php $__currentLoopData = \App\Models\Filiere::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($filiere->id); ?>" <?php echo e($stagiaire->filiere_id==$filiere->id?'selected':null); ?>>
                                <?php echo e($filiere->libelle); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td> ID : </td>
                <td><input value="<?php echo e($stagiaire->id); ?>" class="bg-slate-950 outline outline-1 focus:outline-white rounded" type="number" name="id" readOnly></td>
            </tr>
            <tr>
                <td>Cef : </td>
                <td><input value="<?php echo e($stagiaire->cef); ?>" class="bg-slate-950 outline outline-1 focus:outline-white rounded" type="number" name="cef"></td>
            </tr>
            <tr>
                <td>Nom : </td>
                <td><input value="<?php echo e($stagiaire->nom); ?>" class="bg-slate-950 outline outline-1 focus:outline-white rounded" type="text" name="nom"></td>
            </tr>
            <tr>
                <td>Prenom : </td>
                <td><input value="<?php echo e($stagiaire->prenom); ?>" class="bg-slate-950 outline outline-1 focus:outline-white rounded" type="text" name="prenom"></td>
            </tr>
            <tr>
                <td>Age : </td>
                <td><input value="<?php echo e($stagiaire->age); ?>" class="bg-slate-950 outline outline-1 focus:outline-white rounded" type="number" name="age"></td>
            </tr>
            <tr>
                <td>Email : </td>
                <td><input value="<?php echo e($stagiaire->email); ?>" class="bg-slate-950 outline outline-1 focus:outline-white rounded" type="text" name="email"></td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="flex justify-center gap-2">
                        <button class="p-2 bg-cyan-600 hover:bg-cyan-500 rounded">Enregistrer</button>
                        <a href=<?php echo e(route('stagiaire.index')); ?>><button type="button" class="p-2 bg-cyan-600 hover:bg-cyan-500 rounded">Annuler</button></a>
                    </div>
                </td>
            </tr>
        </table>
    </form>
</body>

</html><?php /**PATH /home/user/laravel/resources/views/stagiaire/modify.blade.php ENDPATH**/ ?>