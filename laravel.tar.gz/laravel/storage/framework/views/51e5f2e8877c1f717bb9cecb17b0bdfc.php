<div>
    <!-- Do what you can, with what you have, where you are. - Theodore Roosevelt -->
</div>
<?php /**PATH /home/user/laravel/resources/views/commandes/index.blade.php ENDPATH**/ ?>