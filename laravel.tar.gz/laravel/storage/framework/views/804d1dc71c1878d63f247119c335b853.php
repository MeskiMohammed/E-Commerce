<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Project</title>
    <script src="https://cdn.tailwindcss.com"></script>

</head>



<body class="bg-slate-950">
    <div class="text-cyan-600 text-center text-5xl font-bold my-2">Stagiaires</div>
    <br>
    <div class="flex flex-col items-center">
        <div class="w-11/12 flex flex-col">
            <a href=<?php echo e(route('stagiaire.create')); ?> class="self-end">
                <button class="p-2 rounded bg-cyan-600 hover:bg-cyan-500 transition-color duration-200 text-white">
                    <?php echo e("Ajouter un Stagiaire"); ?>

                </button>
            </a>
        </div>
        <br>
        <table class="w-11/12 text-white border border-white rounded text-center cursor-default">
            <thead>
                <tr>
                    <th>Filiere</th>
                    <th>ID</th>
                    <th>Cef</th>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Age</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stagiaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stagiaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-900">
                        <td><?php echo e($stagiaire->filiere->libelle); ?></td>
                        <td><?php echo e($stagiaire->id); ?></td>
                        <td><?php echo e($stagiaire->cef); ?></td>
                        <td><?php echo e($stagiaire->nom); ?></td>
                        <td><?php echo e($stagiaire->prenom); ?></td>
                        <td><?php echo e($stagiaire->age); ?></td>
                        <td><?php echo e($stagiaire->email); ?></td>
                        <td>
                            <form action="<?php echo e(route('stagiaire.destroy',$stagiaire->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <a href="<?php echo e(route('stagiaire.edit',$stagiaire->id)); ?>"><button type="button" class="bg-cyan-600 hover:bg-cyan-500 rounded p-2">update</button></a>
                                <button class="bg-red-600 hover:bg-red-500 rounded p-2">delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH /home/user/laravel/resources/views/stagiaire/index.blade.php ENDPATH**/ ?>