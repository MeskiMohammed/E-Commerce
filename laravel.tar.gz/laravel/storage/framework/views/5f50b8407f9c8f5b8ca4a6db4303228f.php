<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Article</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-slate-950 text-white flex flex-col items-center">
    <div class="text-cyan-600 text-center text-5xl font-bold my-2">Create a new Article</div>
    <br>
    <form action=<?php echo e(route('store article')); ?> method="POST">
        <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td>Designation :</td>
                <td><input class="bg-slate-950 outline outline-1" type="text" name="designation"></td>
            </tr>
            <tr>
                <td>Prix HT : </td>
                <td><input class="bg-slate-950 outline outline-1" type="number" name="prix_ht"></td>
            </tr>
            <tr>
                <td>Stock : </td>
                <td><input class="bg-slate-950 outline outline-1" type="number" name="stock"></td>
            </tr>
            <tr>
                <td>TVA : </td>
                <td><input class="bg-slate-950 outline outline-1" type="number" name="tva"></td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="flex justify-center "><button
                            class="p-2 bg-cyan-600 hover:bg-cyan-500 rounded">Save</button></div>
                </td>
            </tr>
        </table>
    </form>
</body>

</html><?php /**PATH C:\Users\PC\Desktop\laravel-app\resources\views/articles/create.blade.php ENDPATH**/ ?>