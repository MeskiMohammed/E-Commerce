<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Project</title>
    <script src="https://cdn.tailwindcss.com"></script>

</head>



<body class="bg-slate-950">
    <div class="text-cyan-600 text-center text-5xl font-bold my-2">Articles</div>
    <br>
    <div class="flex flex-col items-center">
        <div class="w-11/12 flex flex-col">
            <a href=<?php echo e(route('create article')); ?> class="self-end">
                <button class="p-2 rounded bg-cyan-700 hover:bg-cyan-600 transition-color duration-200 text-white">
                    <?php echo e("Ajouter un article"); ?>

                </button>
            </a>
        </div>
        <br>
        <table class="w-11/12 text-white border border-white rounded text-center cursor-default">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Designation</th>
                    <th>Prix HT</th>
                    <th>TVA</th>
                    <th>Prix TTC</th>
                    <th>Stock</th>
                    <th>actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-gray-900 hover:bg-gray-800 transition-color duration-200">
                        <td><?php echo e($article->id); ?></td>
                        <td><?php echo e($article->designation); ?></td>
                        <td><?php echo e($article->prix_ht); ?></td>
                        <td><?php echo e($article->tva); ?></td>
                        <td><?php echo e($article->prix_ht * (1 + $article->tva / 100)); ?></td>
                        <td><?php echo e($article->stock); ?></td>
                        <td class="flex justify-evenly">
                            <a href=<?php echo e(route("edit article", ["id" => $article->id])); ?>><button class="p-2 bg-yellow-500 hover:bg-yellow-400 rounded font-semibold">Update</button></a>
                            <form method="POST" action=<?php echo e(route("delete article", ["id" => $article->id])); ?>>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="p-2 font-semibold bg-red-600 hover:bg-red-500 rounded">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\Users\PC\Desktop\laravel-app\resources\views/articles/index.blade.php ENDPATH**/ ?>