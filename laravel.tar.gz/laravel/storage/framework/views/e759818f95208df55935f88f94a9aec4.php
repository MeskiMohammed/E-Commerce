<?php $__env->startSection('mini title', 'Unites'); ?>
<?php $__env->startSection('adminContent'); ?>
<div class="w-full flex flex-col">

<a href="<?php echo e(route('unites.create')); ?>" class="self-end">
    <button type="button" class="bg-cyan-600 hover:bg-cyan-500 cursor-pointer text-white font-bold py-2 px-4 rounded">Ajouter un Unite</button>
</a>

<table class="w-full text-center mt-4 h-10 overflow-y-auto">
    <thead>
        <tr>
            <th class="bg-gray-200 py-2 rounded-tl-2xl">ID</th>
            <th class="bg-gray-200 py-2">Unite</th>
            <th class="bg-gray-200 py-2 rounded-tr-2xl">Action</th>
        </tr>
    </thead>
    <tbody class="bg-gray-100">
        <?php $__empty_1 = true; $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="hover:bg-slate-200">
            <td class="py-4"><?php echo e($unite->id); ?></td>
            <td class="py-4"><?php echo e($unite->unite); ?></td>
            <td class="max-w-15 py-4 px-2">
                <form action="<?php echo e(route('unites.destroy',$unite)); ?>" method="post" class="flex gap-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <a href="<?php echo e(route('unites.edit',$unite)); ?>">
                        <button type="button" class="bg-yellow-500 hover:bg-yellow-400 cursor-pointer text-white font-bold py-2 px-3 rounded">Update</button>
                    </a>
                    <button type="submit" class="bg-red-600 hover:bg-red-500 cursor-pointer text-white font-bold py-2 px-4 rounded">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4" class="bg-gray-100 rounded-b-2xl">no Unites Found</td>
        </tr>
        <?php endif; ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="4" class="bg-gray-100 rounded-b-2xl">hello foot</td>
        </tr>
    </tfoot>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/laravel/resources/views/unites/index.blade.php ENDPATH**/ ?>