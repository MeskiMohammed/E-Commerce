<?php $__env->startSection('adminContent'); ?>
<?php dd($detailsCommandes); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/laravel/resources/views/detailsCommande/index.blade.php ENDPATH**/ ?>