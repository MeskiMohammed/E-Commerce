<div>
    <!-- When there is no desire, all things are at peace. - Laozi -->
</div>
<?php /**PATH /home/user/laravel/resources/views/etats/index.blade.php ENDPATH**/ ?>