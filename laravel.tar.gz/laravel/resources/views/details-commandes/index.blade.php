@extends('adminLayout.app')
@section('adminContent')
@dd($detailsCommandes)
@endsection