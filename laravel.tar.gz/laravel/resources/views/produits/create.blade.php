@extends('adminLayout.app')
@section('adminContent')
<form action="{{route('products.create')}}" method="post">

</form>
@endsection