@extends('layout.app')
@section('content')
    <p>products</p>
@endsection