@extends('adminLayout.app')
@section('mini title','Ajouter un Marque')
@section('adminContent')
<form action="{{ route('marques.store') }}" method="post" enctype="multipart/form-data">
    @csrf
    <label for="marque">Marque :</label>
    <input type="text" name="marque"><br>
    <button type="submit">Ajouter</button>
    <a href="{{route('marques.index')}}"><button type="button">Annuler</button></a>
</form>
@endsection