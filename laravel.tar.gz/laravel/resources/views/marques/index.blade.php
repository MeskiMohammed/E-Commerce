@extends('adminLayout.app')
@section('mini title', 'Marques')
@section('adminContent')
<div class="w-full flex flex-col">

<a href="{{route('marques.create')}}" class="self-end">
    <button type="button" class="bg-cyan-600 hover:bg-cyan-500 cursor-pointer text-white font-bold py-2 px-4 rounded">Ajouter un Marque</button>
</a>

<table class="w-full text-center mt-4 h-10 overflow-y-auto">
    <thead>
        <tr>
            <th class="bg-gray-200 py-2 rounded-tl-2xl">ID</th>
            <th class="bg-gray-200 py-2">Marque</th>
            <th class="bg-gray-200 py-2 rounded-tr-2xl">Action</th>
        </tr>
    </thead>
    <tbody class="bg-gray-100">
        @foreach($marques as $marque)
        <tr class="hover:bg-slate-200">
            <td class="py-4">{{ $marque->id }}</td>
            <td class="py-4">{{ $marque->marque }}</td>
            <td class="max-w-15 py-4 px-2">
                <form action="{{route('marques.destroy',$marque)}}" method="post" class="flex gap-3">
                    @csrf
                    @method('DELETE')
                    <a href="{{route('marques.edit',$marque)}}">
                        <button type="button" class="bg-yellow-500 hover:bg-yellow-400 cursor-pointer text-white font-bold py-2 px-3 rounded">Update</button>
                    </a>
                    <button type="submit" class="bg-red-600 hover:bg-red-500 cursor-pointer text-white font-bold py-2 px-4 rounded">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
    <tfoot>
        <tr>
            <td colspan="4" class="bg-gray-100 rounded-b-2xl">hello foot</td>
        </tr>
    </tfoot>
</table>
</div>

@endsection