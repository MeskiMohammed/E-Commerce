@extends('adminLayout.app')
@section('mini title','Ajouter un Famille')
@section('adminContent')
<form action="{{ route('familles.store') }}" method="post" enctype="multipart/form-data">
    @csrf
    <label for="libelle">libelle :</label>
    <input type="text" name="libelle"><br>
    <label for="image">image :</label>
    <input type="file" name="image"><br>
    <button type="submit">Ajouter</button>
    <a href="{{route('familles.index')}}"><button type="button">Annuler</button></a>
</form>
@endsection