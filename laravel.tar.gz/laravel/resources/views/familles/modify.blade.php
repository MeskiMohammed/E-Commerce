@extends('adminLayout.app')
@section('mini title','Modifier un Famille')
@section('adminContent')
<form action="{{ route('familles.update', $famille->id) }}" method="post" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <label for="libelle">libelle :</label>
    <input type="text" name="libelle"><br>
    <label for="image">image :</label>
    <input type="file" name="image"><br>
    <button type="submit">Enregistrer</button>
    <a href="{{route('familles.index')}}"><button type="button">Annuler</button></a>
</form>
@endsection