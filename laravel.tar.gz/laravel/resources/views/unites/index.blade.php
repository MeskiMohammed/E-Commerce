@extends('adminLayout.app')
@section('mini title', 'Unites')
@section('adminContent')
<div class="w-full flex flex-col">

<a href="{{route('unites.create')}}" class="self-end">
    <button type="button" class="bg-cyan-600 hover:bg-cyan-500 cursor-pointer text-white font-bold py-2 px-4 rounded">Ajouter un Unite</button>
</a>

<table class="w-full text-center mt-4 h-10 overflow-y-auto">
    <thead>
        <tr>
            <th class="bg-gray-200 py-2 rounded-tl-2xl">ID</th>
            <th class="bg-gray-200 py-2">Unite</th>
            <th class="bg-gray-200 py-2 rounded-tr-2xl">Action</th>
        </tr>
    </thead>
    <tbody class="bg-gray-100">
        @forelse($unites as $unite)
        <tr class="hover:bg-slate-200">
            <td class="py-4">{{ $unite->id }}</td>
            <td class="py-4">{{ $unite->unite }}</td>
            <td class="max-w-15 py-4 px-2">
                <form action="{{route('unites.destroy',$unite)}}" method="post" class="flex gap-3">
                    @csrf
                    @method('DELETE')
                    <a href="{{route('unites.edit',$unite)}}">
                        <button type="button" class="bg-yellow-500 hover:bg-yellow-400 cursor-pointer text-white font-bold py-2 px-3 rounded">Update</button>
                    </a>
                    <button type="submit" class="bg-red-600 hover:bg-red-500 cursor-pointer text-white font-bold py-2 px-4 rounded">Delete</button>
                </form>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="4" class="bg-gray-100 rounded-b-2xl">no Unites Found</td>
        </tr>
        @endforelse
    </tbody>
    <tfoot>
        <tr>
            <td colspan="4" class="bg-gray-100 rounded-b-2xl">hello foot</td>
        </tr>
    </tfoot>
</table>
</div>
@endsection