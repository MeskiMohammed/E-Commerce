@extends('adminLayout.app')
@section('mini title','Ajoutet un Unite')
@section('adminContent')
<form action="{{ route('unites.store') }}" method="post" enctype="multipart/form-data">
    @csrf
    <label for="unite">Unite :</label>
    <input type="text" name="unite"><br>
    <button type="submit">Ajouter</button>
    <a href="{{route('unites.index')}}"><button type="button">Annuler</button></a>
</form>
@endsection