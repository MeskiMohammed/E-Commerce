<?php

namespace App\Http\Controllers;

use App\Models\Produit;
use App\Models\SousFamille;
use Illuminate\Http\Request;

class SousFamilleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view("sous-familles.index", ["sous-familles"=> SousFamille::all()]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('sous-familles.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        SousFamille::create('$request->all()');
        return redirect(route('sous-familles.index'));
    }

    /**
     * Display the specified resource.
     */
    public function show(SousFamille $sousFamille)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SousFamille $sousFamille)
    {
        return view('produits.modify',$sousFamille);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SousFamille $sousFamille)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SousFamille $sousFamille)
    {
        $sousFamille->delete();
        return redirect(route('sous-familles.index'));
    }
}
